package com.example.databaseexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import com.example.databaseexample.enitities.Film
import kotlinx.coroutines.launch


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//tworzymy obiekt i mamy dostep do naszej bazy filmow
var obiekt=BazaFilmow()
        val dao2=BigDatabase.getInstance(this).filmyDAO
        lifecycleScope.launch {
            obiekt.baza_filmow.forEach { dao2.dodajFilm(it) }
    }
    }
}