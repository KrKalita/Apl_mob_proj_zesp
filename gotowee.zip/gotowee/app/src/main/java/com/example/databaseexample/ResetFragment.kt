package com.example.databaseexample

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.databaseexample.films.DodajFilmViewModel

class ResetFragment: Fragment() {


    private lateinit var viewModel2:DodajFilmViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        viewModel2=ViewModelProvider(requireActivity()).
        get(DodajFilmViewModel::class.java)


        return inflater.inflate(R.layout.fragment_reset,container,false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<Button>(R.id.reset2).apply {
            setOnClickListener {
                viewModel2.deleteMovies()
                val message="Usunięto bazę danych!!!!"
                Toast.makeText(context,message,Toast.LENGTH_SHORT).show()
                }
            }


}
}

