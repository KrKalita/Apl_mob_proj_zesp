package com.example.databaseexample.enitities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
//tworzenie tablicy filmow
@Entity(tableName = "movie_table")
data class Film(
    @PrimaryKey(autoGenerate = false)
    @ColumnInfo(name="Tytul")
    var movieName:String,
    @ColumnInfo(name="Opis")
    var movieDesc:String,
    @ColumnInfo(name="Rok")
    var year:Int,
    @ColumnInfo(name="Zrodlo")
    var zrodlo:String

)