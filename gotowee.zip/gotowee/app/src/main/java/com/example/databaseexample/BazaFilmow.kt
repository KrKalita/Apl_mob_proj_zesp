package com.example.databaseexample

import com.example.databaseexample.enitities.Film
//baza naszych filmow
class BazaFilmow {
    val baza_filmow = listOf(
        Film("INTERSTELLAR","Byt ludzkości na Ziemi dobiega końca wskutek zmian klimatycznych. Grupa naukowców odkrywa tunel czasoprzestrzenny, który umożliwia poszukiwanie nowego domu.",
            2014,"https://www.filmweb.pl/film/Interstellar-2014-375629"),
        Film("CHAPPIE","W dzisiejszych czasach roboty do zadań specjalnych stają się codziennością. W brutalnym świecie Johannesburga policja i wojsko używają ich do tłumienia zamieszek i walki z gangsterami. Chappie jest jednym z robotów nowej generacji, które myślą i czują. Niewiele różni się od nas, ludzi. Jest jak dziecko i tak jak ono poznaje świat oczyma opiekunów. Kiedy Chappie dostaje się w ręce gangsterów, ci resetują jego dotychczasową wiedzę i uczą wszystkiego od nowa, tak by pracował dla nich. Poczciwy, budzący sympatię robot, nie do końca świadomy wyrządzania zła, uczestniczy w brutalnych napadach rabunkowych i życiu przestępczego półświatka.",
            2015,"https://www.filmweb.pl/film/Chappie-2015-612189"),
        Film("INCEPCJA","Czasy, gdy technologia pozwala na wchodzenie w świat snów. Złodziej Cobb ma za zadanie wszczepić myśl do śpiącego umysłu.",
            2010,"https://www.filmweb.pl/film/Incepcja-2010-500891"),
        Film("tytul2","opis2",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul3","opis3",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul4","opis4",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul5","opis5",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul6","opis6",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul7","opis7",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul8","opis8",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul9","opis9",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul10","opis0",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul11","opis1",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul12","opis2",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul13","opis3",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul14","opis4",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul15","opis5",1234,"https://www.youtube.com/watch?v=N7ch-RVO1sA"),
        Film("tytul16","opis5",1234,"cos")
    )
}