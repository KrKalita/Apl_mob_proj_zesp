package com.example.databaseexample.films

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.databaseexample.BigDatabase
import com.example.databaseexample.enitities.Film
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class DodajFilmViewModel(application: Application): AndroidViewModel(application) {

          private val filmyDAO :FilmyDAO
          init{
              filmyDAO=BigDatabase.getInstance(application).filmyDAO

          }
//dodanie filmu
           fun addMovie(film: Film) {

               viewModelScope.launch(Dispatchers.IO){
                  filmyDAO.dodajFilm(film)//dodanie filmu
             }
        }
    //usuniecie filmow
    fun deleteMovies(){
        filmyDAO.usunWszystkieFilmy()
    }

}