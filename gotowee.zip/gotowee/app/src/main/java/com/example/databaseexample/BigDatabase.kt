package com.example.databaseexample

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.databaseexample.enitities.Film
import com.example.databaseexample.films.FilmyDAO

@Database(entities=[Film::class], version = 1, exportSchema = false)
abstract class BigDatabase: RoomDatabase() {

    abstract val filmyDAO: FilmyDAO
    companion object {

        @Volatile
        private var INSTANCE: BigDatabase? = null

        fun getInstance(context: Context): BigDatabase {
              synchronized(this) {
                var instance = INSTANCE

                if (instance == null) {
                    instance = Room.databaseBuilder(
                        context.applicationContext,
                        BigDatabase::class.java,
                        "data_base_movies"
                    )
                        .allowMainThreadQueries().fallbackToDestructiveMigration()
                        .build()

                    INSTANCE = instance
                }
                return instance
            }
        }
    }

}