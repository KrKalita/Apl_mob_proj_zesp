package com.example.databaseexample.films

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.lifecycle.LiveData
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.databaseexample.R
import com.example.databaseexample.enitities.Film
var tablica= mutableListOf<Int>()
var opis1=""
var tytul1=""
var link1=""
class MoviesListAdapter(private val view: View,private val movies: LiveData<List<Film>>, private val viewModel: FilmyListaViewModel)
    :RecyclerView.Adapter<MoviesListAdapter.MoviesListHolder>()
{
    inner class MoviesListHolder(private val view: View): RecyclerView.ViewHolder(view)
    {
        val textViewFirstName=view.findViewById<TextView>(R.id.tytul)
        val textViewAlbum=view.findViewById<TextView>(R.id.rok)
        val buttonEdit=view.findViewById<Button>(R.id.button_delete_movie)
        val buttonEdit2=view.findViewById<Button>(R.id.button_opis)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MoviesListHolder {
        val view=LayoutInflater.from(parent.context).
                inflate(R.layout.jeden_film_wiersz,parent,false)
        return MoviesListHolder(view)
    }

    override fun onBindViewHolder(holder: MoviesListHolder, position: Int) {
        holder.textViewFirstName.text=movies.value?.get(position)?.movieName
        holder.textViewAlbum.text=movies.value?.get(position)?. year.toString()
        holder.buttonEdit.setOnClickListener {
            movies.value?.let{ existingMovies->
                viewModel.deleteMovie(existingMovies.get(position))

            }
        }
        holder.buttonEdit2.setOnClickListener {
            opis1=movies.value?.get(position)?.movieDesc.toString()
            tytul1=movies.value?.get(position)?.movieName.toString()
            link1=movies.value?.get(position)?.zrodlo.toString()
            view.findNavController().navigate(R.id.action_movieListFragment_to_opisFragment)

        }
    }

    override fun getItemCount()=movies.value?.size?:0

}