package com.example.databaseexample.films

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.databaseexample.enitities.Film

@Dao
interface FilmyDAO  {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun dodajFilm(film: Film)

    @Delete
    fun usunFilm(film:Film)

    @Query("SELECT * FROM movie_table WHERE Tytul LIKE :tytul")
    fun getAll(tytul: String): LiveData<List<Film>>
    @Query("SELECT * FROM movie_table")
    fun getAll2(): LiveData<List<Film>>
    @Query("DELETE FROM movie_table")
    fun usunWszystkieFilmy()
    @Query("SELECT * FROM movie_table WHERE Tytul = :tytul")
    fun szukaj(tytul: String): LiveData<List<Film>>

}