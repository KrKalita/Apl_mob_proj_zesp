package com.example.databaseexample.films

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.databaseexample.R

class OpisFragment: Fragment() {


    private lateinit var viewModel:DodajFilmViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
      viewModel=ViewModelProvider(requireActivity()).
                   get(DodajFilmViewModel::class.java)


        return inflater.inflate(R.layout.fragment_opis,container,false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //wyciaganie danych i przypisanie ich
        var opis=view.findViewById<TextView>(R.id.opis2);
        opis.setText(opis1);
        var tytul=view.findViewById<TextView>(R.id.tytul2);
        tytul.setText(tytul1);
        var link=view.findViewById<TextView>(R.id.link2);
        link.setText("Źródło: "+link1);
        var adress= link1
        view.findViewById<TextView>(R.id.buttonWejdz).setOnClickListener {
            if(adress==""){

            }else{
                var channelRevolShen=
                    Intent(Intent.ACTION_VIEW, Uri.parse(adress))//action to wyswietla nam, parsowanie do uri
                startActivity(channelRevolShen)
            }
        }

}
}

