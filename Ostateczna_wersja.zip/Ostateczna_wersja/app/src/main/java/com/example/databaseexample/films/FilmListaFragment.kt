package com.example.databaseexample.films

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.databaseexample.R
import com.example.databaseexample.enitities.Film

class FilmListaFragment: Fragment() {

    lateinit var viewModel: FilmyListaViewModel
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {



        return inflater.inflate(R.layout.fragment_film_lista,container,false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory=FilmyListaViewModelFactory((requireNotNull(this.activity).application))
        viewModel=ViewModelProvider(requireActivity(),factory).
        get(FilmyListaViewModel::class.java)


        val moviesListAdapter=MoviesListAdapter(view,viewModel.movies,viewModel)

        viewModel.movies.observe(viewLifecycleOwner,
            Observer<List<Film>> { moviesListAdapter.notifyDataSetChanged() }

        )


        val layoutManager=LinearLayoutManager(view.context)
        view.findViewById<RecyclerView>(R.id.movies_recyclerView).let {

            it.adapter=moviesListAdapter
            it.layoutManager=layoutManager
        }
        view.findViewById<Button>(R.id.dodajFilm).apply {
            setOnClickListener {
                it.findNavController().navigate(R.id.filmFragment)
            }
        }
        view.findViewById<Button>(R.id.szukaj123).apply {
            setOnClickListener {
                //szukanie filmow
                var wpisany_tekst=view.findViewById<EditText>(R.id.wpisany_tekst).getText().toString();
                if(wpisany_tekst==""){
                    szukaj="%"
                }else{
                    szukaj=wpisany_tekst+"%"
                }

                viewModel.szukaj3()

//aktualizowanie danych
                val moviesListAdapter=MoviesListAdapter(view,viewModel.movies,viewModel)

                viewModel.movies.observe(viewLifecycleOwner,
                    Observer<List<Film>> { moviesListAdapter.notifyDataSetChanged() }

                )


                val layoutManager=LinearLayoutManager(view.context)
                view.findViewById<RecyclerView>(R.id.movies_recyclerView).let {

                    it.adapter=moviesListAdapter
                    it.layoutManager=layoutManager
                }
            }
        }
    }

}