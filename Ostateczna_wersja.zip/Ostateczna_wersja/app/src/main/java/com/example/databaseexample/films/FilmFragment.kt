package com.example.databaseexample.films

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.databaseexample.R
import com.example.databaseexample.enitities.Film

class FilmFragment: Fragment() {


    private lateinit var viewModel:DodajFilmViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
      viewModel=ViewModelProvider(requireActivity()).
                   get(DodajFilmViewModel::class.java)


        return inflater.inflate(R.layout.fragment_film,container,false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

val opis2=view.findViewById<TextView>(R.id.opis)
        val rok2=view.findViewById<TextView>(R.id.rok)
        val tytul2=view.findViewById<TextView>(R.id.tytul)
        val link2=view.findViewById<TextView>(R.id.zrodlo)
        view.findViewById<Button>(R.id.button_add_movie).apply {
            setOnClickListener {
                //zabezpiecznie
                if(rok2.text.toString()==""){
                    var c=view.findViewById<TextView>(R.id.rok);
                    c.setText("0");
                }
                    val movie=Film(tytul2.text.toString(),opis2.text.toString(),rok2.text.toString().toInt(),link2.text.toString())
                           viewModel.addMovie(movie)
                val message="Dodano film!"
                Toast.makeText(context,message, Toast.LENGTH_SHORT).show()
                }
            }


}
}

