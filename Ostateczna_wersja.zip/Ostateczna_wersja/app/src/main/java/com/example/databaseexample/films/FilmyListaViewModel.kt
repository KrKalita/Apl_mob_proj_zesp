package com.example.databaseexample.films

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.databaseexample.BigDatabase
import com.example.databaseexample.enitities.Film
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
var szukaj="%"
class FilmyListaViewModel(
    application: Application):
          AndroidViewModel(application) {

    private val filmyDAO :FilmyDAO = BigDatabase.getInstance(application).filmyDAO
    var movies:LiveData<List<Film>> = filmyDAO.getAll(szukaj)

    fun deleteMovie(film: Film)
    {
        viewModelScope.launch(Dispatchers.IO) {
            filmyDAO.usunFilm(film)
        }
    }
    fun szukaj3(){
        movies=filmyDAO.getAll(szukaj)
    }


}