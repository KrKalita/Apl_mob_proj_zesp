package com.lukaszkopka.movieapp

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface Api {
    @GET("movie/popular")
    fun getPopularMovies(
        @Query("api_key") apiKey: String = "4683e4c64c130b6a5553aafc6fbb7207v",
        @Query("page") page: Int
    ): Call<GetMoviesResponse>
}