package com.lukaszkopka.movieapp.data

import androidx.lifecycle.LiveData

class MovieRepository(private val movieDao: MovieDao) {
    val readdAllData: LiveData<List<Movie>> = movieDao.readAllData()

    suspend fun addMovie(movie: Movie){
        movieDao.addMovie(movie)
    }
}