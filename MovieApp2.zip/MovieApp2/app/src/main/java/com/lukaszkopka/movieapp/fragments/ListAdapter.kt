package com.lukaszkopka.movieapp.fragments

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lukaszkopka.movieapp.R
import com.lukaszkopka.movieapp.data.Movie
import kotlinx.android.synthetic.main.custom_row.view.*

class ListAdapter: RecyclerView.Adapter<ListAdapter.MyViewHolder>() {

    private var movieList = emptyList<Movie>()

    class MyViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return  MyViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.custom_row,parent,false))
    }

    override fun getItemCount(): Int {
        return movieList.size

    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = movieList[position]
        holder.itemView.id_txt.text = currentItem.id.toString()
        holder.itemView.movieName_txt.text = currentItem.movieName
        holder.itemView.movieYear_txt.text = currentItem.year.toString()
    }

    fun setData(movie: List<Movie>){
        this.movieList = movie
        notifyDataSetChanged()
    }
}